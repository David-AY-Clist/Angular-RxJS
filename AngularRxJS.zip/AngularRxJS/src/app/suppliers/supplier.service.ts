import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { throwError, Observable, of } from 'rxjs';
import { catchError, concatMap, map, mergeMap, shareReplay, switchMap, tap } from 'rxjs/operators';
import { Supplier } from './supplier';

@Injectable({
  providedIn: 'root'
})
export class SupplierService {
  suppliersUrl = 'api/suppliers';


  suppliers$ = this.http.get<Supplier[]>(this.suppliersUrl)
  .pipe(
    tap(data => console.log('supplier', JSON.stringify(data))),
    shareReplay(1),
    catchError(this.handleError)
    );

  supplierWithMap$ = of(1,5,8)
  .pipe(
       map(id => this.http.get<Supplier>(`${this.suppliersUrl}/${id}`)
       )
  );


  supplierWithConcatMap$ = of(1,5,8)
  .pipe(
       tap(id => console.log('concatMap source observable', id)),
       concatMap(id => this.http.get<Supplier>(`${this.suppliersUrl}/${id}`))
       );

  
  supplierWithMergMap$ = of(1,5,8)
  .pipe(
      tap(id => console.log('SwitchMpa source observable', id)),
      mergeMap(id => this.http.get<Supplier>(`${this.suppliersUrl}/${id}`))
      );

  
  supplierWithSwitchMap$ = of(1,5,8)
  .pipe(
      tap(id => console.log('MergeMap source observable', id)),
      switchMap(id => this.http.get<Supplier>(`${this.suppliersUrl}/${id}`))
      );
  
      


  constructor(private http: HttpClient) { 
    
  }

  private handleError(err: any): Observable<never> {
   
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      
      errorMessage = `Backend returned code ${err.status}: ${err.body.error}`;
    }
    console.error(err);
    return throwError(errorMessage);
  }

}
