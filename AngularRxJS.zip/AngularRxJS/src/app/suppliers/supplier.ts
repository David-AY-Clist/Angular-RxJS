/* Defines the supplier entity */
export interface Supplier {
  id: number;
  name: string;
  cost: number;
  minQuantity: number;
}
